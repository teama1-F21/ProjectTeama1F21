//homepage
/*

dineIn.onclick=function(){
  ChangeForm(login)
}

dineOut.onclick=function(){
  ChangeForm(dineOut)
}

favorite.onclick=function(){
  ChangeForm(favorite)
}

calorieTracker.onclick=function(){
  ChangeForm(calorieTracker)
}
*/