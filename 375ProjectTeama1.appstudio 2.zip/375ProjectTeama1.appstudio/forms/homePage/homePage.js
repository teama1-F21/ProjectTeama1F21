//homepage


dineIn.onclick=function(){
  ChangeForm(dineInHome)
}

dineOut.onclick=function(){
  ChangeForm(api)
}

favorite.onclick=function(){
  ChangeForm(favorites)
}

calorieTracker.onclick=function(){
  ChangeForm(calTracker)
}
